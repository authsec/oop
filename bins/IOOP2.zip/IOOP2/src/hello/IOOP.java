/*
 * IOOP.java
 *
 * Created on 19. Februar 2006, 22:48
 */

package hello;

import java.util.Enumeration;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import org.coffeecrew.mobile.oop.impl.BulkObjectPusher;
import org.coffeecrew.mobile.oop.impl.ObjectPusher;
import org.coffeecrew.mobile.oop.impl.ObjectReceiver;
import org.coffeecrew.mobile.oop.exceptions.ObjectNotPassableException;
import org.coffeecrew.mobile.oop.util.InspectBT;
import org.coffeecrew.mobile.oop.util.Observable;
import org.coffeecrew.mobile.oop.util.Observer;
import org.coffeecrew.da.entity.Person;
/**
 *
 * @author Jens Frey <jens.frey@coffeecrew.org>
 */
public class IOOP extends MIDlet implements CommandListener, Observer
{
    private ObjectReceiver or = null;
    private ObjectPusher op = null;
    private Vector receivedObjects = null;
    
    /** Creates a new instance of IOOP */
    public IOOP()
    {
        initialize();
    }
    
    private Form displayDataForm;//GEN-BEGIN:MVDFields
    private Form sendObjectForm;
    private Form welcomeForm;
    private Command exitCommand1;
    private Command displayDataForm1;
    private Command sendDataForm;
    private TextField addressField;
    private Command backFromDisplayData;
    private Command backFromSendForm;
    private Command findDevicesCommand;
    private Command backFromDeviceList;
    private Command startServerCommand;
    private Command sendCommand;
    private Form deviceInfoForm;
    private Command deviceInfoCommand;
    private Command backFromDeviceInfoCommand;//GEN-END:MVDFields
    
//GEN-LINE:MVDMethods

    /** Called by the system to indicate that a command has been invoked on a particular displayable.//GEN-BEGIN:MVDCABegin
     * @param command the Command that ws invoked
     * @param displayable the Displayable on which the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {//GEN-END:MVDCABegin
    // Insert global pre-action code here
        if (displayable == welcomeForm) {//GEN-BEGIN:MVDCABody
            if (command == displayDataForm1) {//GEN-END:MVDCABody
                // Insert pre-action code here
                get_displayDataForm().deleteAll();
                
                /* Check if vector is maybe not initialized or empty
                 */
                if ( receivedObjects == null || receivedObjects.isEmpty())
                {
                    TextField error = new TextField("Error occured:", "No displayable object found", 120, TextField.ANY);
                    get_displayDataForm().append(error);
                }
                else
                {
                    /* Fetch the received objects and display
                     * it
                     */
                    Enumeration e = receivedObjects.elements();
                    while (e.hasMoreElements())
                    {
                        //PersonStore ps = (PersonStore) e.nextElement();
                        //ps.printPersons();
                        
                    Person p = (Person) e.nextElement();
                    
                    TextField name = new TextField("Person Name", p.getName(), 120, TextField.ANY);
                    TextField vorname = new TextField("Person Vorname", p.getVorname(), 120, TextField.ANY);
                    TextField age = new TextField("Person Age", new Integer(p.getAge()).toString(), 120, TextField.ANY);
                    
                    get_displayDataForm().append(name);
                    get_displayDataForm().append(vorname);
                    get_displayDataForm().append(age);
                    }
                }
                getDisplay().setCurrent(get_displayDataForm());//GEN-LINE:MVDCAAction8
                // Insert post-action code here
            } else if (command == exitCommand1) {//GEN-LINE:MVDCACase8
                // Insert pre-action code here
                exitMIDlet();//GEN-LINE:MVDCAAction6
                // Insert post-action code here
            } else if (command == sendDataForm) {//GEN-LINE:MVDCACase6
                // Insert pre-action code here
                
                getDisplay().setCurrent(get_sendObjectForm());//GEN-LINE:MVDCAAction10
                // Insert post-action code here
                
            } else if (command == startServerCommand) {//GEN-LINE:MVDCACase10
                // Insert pre-action code here
                /* Maybe set an (configurable) initial object Value
                 * so we do not have to reallocate much space
                 */
                if (receivedObjects == null)
                    receivedObjects = new Vector();
                
                /* Do work on global Object receiver instance
                 * or object will be lost
                 */
                new ObjectReceiver(receivedObjects);
                // Do nothing//GEN-LINE:MVDCAAction23
                // Insert post-action code here
            } else if (command == deviceInfoCommand) {//GEN-LINE:MVDCACase23
                // Insert pre-action code here
                getDisplay().setCurrent(get_deviceInfoForm());//GEN-LINE:MVDCAAction28
                // Insert post-action code here
                InspectBT ibt = new InspectBT();
                get_deviceInfoForm().deleteAll();
                get_deviceInfoForm().append(ibt.getAllProperties());
            }//GEN-BEGIN:MVDCACase28
        } else if (displayable == displayDataForm) {
            if (command == backFromDisplayData) {//GEN-END:MVDCACase28
                // Insert pre-action code here
                getDisplay().setCurrent(get_welcomeForm());//GEN-LINE:MVDCAAction13
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase13
        } else if (displayable == sendObjectForm) {
            if (command == backFromSendForm) {//GEN-END:MVDCACase13
                // Insert pre-action code here
                getDisplay().setCurrent(get_welcomeForm());//GEN-LINE:MVDCAAction15
                // Insert post-action code here
            } else if (command == sendCommand) {//GEN-LINE:MVDCACase15
                // Insert pre-action code here
                Person p = new Person();
                p.setName("Schneider");
                p.setVorname("Rosemarie");
                p.setAge(37);
                              
                Person hans = new Person();
                hans.setName("Peter");
                hans.setVorname("Hans");
                hans.setAge(37);
                
                /* construct wrong object */
                Vector v = new Vector();v.addElement("Lala");
                
                Vector transferringObjects = new Vector();
                transferringObjects.addElement(p);
                //transferringObjects.addElement(v);
                transferringObjects.addElement(hans);
                
                new BulkObjectPusher(transferringObjects).addObserver(this);
                
                getDisplay().setCurrent(get_welcomeForm());//GEN-LINE:MVDCAAction25
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase25
        } else if (displayable == deviceInfoForm) {
            if (command == backFromDeviceInfoCommand) {//GEN-END:MVDCACase25
                // Insert pre-action code here
                getDisplay().setCurrent(get_welcomeForm());//GEN-LINE:MVDCAAction30
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase30
        }//GEN-END:MVDCACase30
    // Insert global post-action code here
}//GEN-LINE:MVDCAEnd

    /** This method initializes UI of the application.//GEN-BEGIN:MVDInitBegin
     */
    private void initialize() {//GEN-END:MVDInitBegin
        // Insert pre-init code here
        deviceInfoCommand = new Command("Device Info", Command.SCREEN, 1);//GEN-BEGIN:MVDInitInit
        backFromDeviceInfoCommand = new Command("Back", Command.BACK, 1);
        getDisplay().setCurrent(get_welcomeForm());//GEN-END:MVDInitInit
        // Insert post-init code here
    }//GEN-LINE:MVDInitEnd
    
    /**
     * This method should return an instance of the display.
     */
    public Display getDisplay()//GEN-FIRST:MVDGetDisplay
    {
        return Display.getDisplay(this);
    }//GEN-LAST:MVDGetDisplay
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet()//GEN-FIRST:MVDExitMidlet
    {
        getDisplay().setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }//GEN-LAST:MVDExitMidlet

    /** This method returns instance for displayDataForm component and should be called instead of accessing displayDataForm field directly.//GEN-BEGIN:MVDGetBegin2
     * @return Instance for displayDataForm component
     */
    public Form get_displayDataForm() {
        if (displayDataForm == null) {//GEN-END:MVDGetBegin2
            // Insert pre-init code here
            displayDataForm = new Form(null, new Item[0]);//GEN-BEGIN:MVDGetInit2
            displayDataForm.addCommand(get_backFromDisplayData());
            displayDataForm.setCommandListener(this);//GEN-END:MVDGetInit2
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd2
        return displayDataForm;
    }//GEN-END:MVDGetEnd2

    /** This method returns instance for sendObjectForm component and should be called instead of accessing sendObjectForm field directly.//GEN-BEGIN:MVDGetBegin3
     * @return Instance for sendObjectForm component
     */
    public Form get_sendObjectForm() {
        if (sendObjectForm == null) {//GEN-END:MVDGetBegin3
            // Insert pre-init code here
            sendObjectForm = new Form("Datatransfer ...", new Item[] {get_addressField()});//GEN-BEGIN:MVDGetInit3
            sendObjectForm.addCommand(get_backFromSendForm());
            sendObjectForm.addCommand(get_sendCommand());
            sendObjectForm.setCommandListener(this);//GEN-END:MVDGetInit3
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd3
        return sendObjectForm;
    }//GEN-END:MVDGetEnd3

    /** This method returns instance for welcomeForm component and should be called instead of accessing welcomeForm field directly.//GEN-BEGIN:MVDGetBegin4
     * @return Instance for welcomeForm component
     */
    public Form get_welcomeForm() {
        if (welcomeForm == null) {//GEN-END:MVDGetBegin4
            // Insert pre-init code here
            welcomeForm = new Form(null, new Item[0]);//GEN-BEGIN:MVDGetInit4
            welcomeForm.addCommand(get_exitCommand1());
            welcomeForm.addCommand(get_displayDataForm1());
            welcomeForm.addCommand(get_sendDataForm());
            welcomeForm.addCommand(get_startServerCommand());
            welcomeForm.addCommand(deviceInfoCommand);
            welcomeForm.setCommandListener(this);//GEN-END:MVDGetInit4
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd4
        return welcomeForm;
    }//GEN-END:MVDGetEnd4

    /** This method returns instance for exitCommand1 component and should be called instead of accessing exitCommand1 field directly.//GEN-BEGIN:MVDGetBegin5
     * @return Instance for exitCommand1 component
     */
    public Command get_exitCommand1() {
        if (exitCommand1 == null) {//GEN-END:MVDGetBegin5
            // Insert pre-init code here
            exitCommand1 = new Command("Exit", Command.EXIT, 1);//GEN-LINE:MVDGetInit5
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd5
        return exitCommand1;
    }//GEN-END:MVDGetEnd5

    /** This method returns instance for displayDataForm1 component and should be called instead of accessing displayDataForm1 field directly.//GEN-BEGIN:MVDGetBegin7
     * @return Instance for displayDataForm1 component
     */
    public Command get_displayDataForm1() {
        if (displayDataForm1 == null) {//GEN-END:MVDGetBegin7
            // Insert pre-init code here
            displayDataForm1 = new Command("Display", Command.SCREEN, 1);//GEN-LINE:MVDGetInit7
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd7
        return displayDataForm1;
    }//GEN-END:MVDGetEnd7

    /** This method returns instance for sendDataForm component and should be called instead of accessing sendDataForm field directly.//GEN-BEGIN:MVDGetBegin9
     * @return Instance for sendDataForm component
     */
    public Command get_sendDataForm() {
        if (sendDataForm == null) {//GEN-END:MVDGetBegin9
            // Insert pre-init code here
            sendDataForm = new Command("Send Data", Command.SCREEN, 1);//GEN-LINE:MVDGetInit9
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd9
        return sendDataForm;
    }//GEN-END:MVDGetEnd9

    /** This method returns instance for addressField component and should be called instead of accessing addressField field directly.//GEN-BEGIN:MVDGetBegin11
     * @return Instance for addressField component
     */
    public TextField get_addressField() {
        if (addressField == null) {//GEN-END:MVDGetBegin11
            // Insert pre-init code here
            addressField = new TextField("Sending Data", "Your data will be automagically send to the remote device on which the Obex object passing server runs if you hit the send button", 250, TextField.ANY);//GEN-LINE:MVDGetInit11
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd11
        return addressField;
    }//GEN-END:MVDGetEnd11

    /** This method returns instance for backFromDisplayData component and should be called instead of accessing backFromDisplayData field directly.//GEN-BEGIN:MVDGetBegin12
     * @return Instance for backFromDisplayData component
     */
    public Command get_backFromDisplayData() {
        if (backFromDisplayData == null) {//GEN-END:MVDGetBegin12
            // Insert pre-init code here
            backFromDisplayData = new Command("Back", Command.BACK, 1);//GEN-LINE:MVDGetInit12
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd12
        return backFromDisplayData;
    }//GEN-END:MVDGetEnd12

    /** This method returns instance for backFromSendForm component and should be called instead of accessing backFromSendForm field directly.//GEN-BEGIN:MVDGetBegin14
     * @return Instance for backFromSendForm component
     */
    public Command get_backFromSendForm() {
        if (backFromSendForm == null) {//GEN-END:MVDGetBegin14
            // Insert pre-init code here
            backFromSendForm = new Command("Back", Command.BACK, 1);//GEN-LINE:MVDGetInit14
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd14
        return backFromSendForm;
    }//GEN-END:MVDGetEnd14
 
    /** This method returns instance for findDevicesCommand component and should be called instead of accessing findDevicesCommand field directly.//GEN-BEGIN:MVDGetBegin18
     * @return Instance for findDevicesCommand component
     */
    public Command get_findDevicesCommand() {
        if (findDevicesCommand == null) {//GEN-END:MVDGetBegin18
            // Insert pre-init code here
            findDevicesCommand = new Command("Find", Command.SCREEN, 1);//GEN-LINE:MVDGetInit18
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd18
        return findDevicesCommand;
    }//GEN-END:MVDGetEnd18

    /** This method returns instance for backFromDeviceList component and should be called instead of accessing backFromDeviceList field directly.//GEN-BEGIN:MVDGetBegin20
     * @return Instance for backFromDeviceList component
     */
    public Command get_backFromDeviceList() {
        if (backFromDeviceList == null) {//GEN-END:MVDGetBegin20
            // Insert pre-init code here
            backFromDeviceList = new Command("Back", Command.BACK, 1);//GEN-LINE:MVDGetInit20
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd20
        return backFromDeviceList;
    }//GEN-END:MVDGetEnd20

    /** This method returns instance for startServerCommand component and should be called instead of accessing startServerCommand field directly.//GEN-BEGIN:MVDGetBegin22
     * @return Instance for startServerCommand component
     */
    public Command get_startServerCommand() {
        if (startServerCommand == null) {//GEN-END:MVDGetBegin22
            // Insert pre-init code here
            startServerCommand = new Command("Serve", Command.SCREEN, 1);//GEN-LINE:MVDGetInit22
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd22
        return startServerCommand;
    }//GEN-END:MVDGetEnd22

    /** This method returns instance for sendCommand component and should be called instead of accessing sendCommand field directly.//GEN-BEGIN:MVDGetBegin24
     * @return Instance for sendCommand component
     */
    public Command get_sendCommand() {
        if (sendCommand == null) {//GEN-END:MVDGetBegin24
            // Insert pre-init code here
            sendCommand = new Command("Send", Command.OK, 1);//GEN-LINE:MVDGetInit24
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd24
        return sendCommand;
    }//GEN-END:MVDGetEnd24

    /** This method returns instance for deviceInfoForm component and should be called instead of accessing deviceInfoForm field directly.//GEN-BEGIN:MVDGetBegin26
     * @return Instance for deviceInfoForm component
     */
    public Form get_deviceInfoForm() {
        if (deviceInfoForm == null) {//GEN-END:MVDGetBegin26
            // Insert pre-init code here
            deviceInfoForm = new Form(null, new Item[0]);//GEN-BEGIN:MVDGetInit26
            deviceInfoForm.addCommand(backFromDeviceInfoCommand);
            deviceInfoForm.setCommandListener(this);//GEN-END:MVDGetInit26
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd26
        return deviceInfoForm;
    }//GEN-END:MVDGetEnd26
    
    public void startApp()
    {
    }
    
    public void pauseApp()
    {
    }
    
    public void destroyApp(boolean unconditional)
    {
    }

    public void update(Observable observable, Object arg)
    {
        /* Do visual update, reuse display DataForm */
        get_displayDataForm().deleteAll();
        Alert finished = new Alert("Transfer finished!", "Your transfer to the remote device is finished", null, AlertType.INFO);
        finished.setTimeout(Alert.FOREVER);
        getDisplay().setCurrent(finished);
    }
    

}
