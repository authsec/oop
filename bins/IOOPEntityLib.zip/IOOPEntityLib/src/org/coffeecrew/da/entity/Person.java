/*
 * Person.java
 *
 * Created on 19. Februar 2006, 22:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.da.entity;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import org.coffeecrew.mobile.oop.IObexObjectPassing;

/**
 *
 * @author jfrey
 */
public class Person implements IObexObjectPassing
{
    /* entity fields */
    private String name = null;
    private String vorname = null;
    private int age = 0;
    
    /* Globals */
    private ByteArrayOutputStream bout = null;
    private DataOutputStream dout = null;
    
    private ByteArrayInputStream bin = null;
    private DataInputStream din = null;
    
    /** Creates a new instance of Person */
    public Person()
    {
    }
    
    public Person(String name, String vorname, int age)
    {
        this.name = name;
        this.vorname = vorname;
        this.age = age;
    }
    
    /* Return the datastructure as byte[] */
    public byte[] getAsByteArray()
    {
        bout = new ByteArrayOutputStream();
        dout = new DataOutputStream( bout );
        byte[] ret = null;
        
        try
        {
            
            /* Write values */
            dout.writeUTF(name);
            dout.writeUTF(vorname);
            dout.writeInt(age);
            dout.flush();
            
            /* do temp copy so we can close
             * the writers
             */
            ret = bout.toByteArray();
            dout.close();
            bout.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        
        
        return ret;
    }
     
    public void setObjectData(byte[] ba)
    {
        bin = new ByteArrayInputStream(ba);
        din = new DataInputStream(bin);
        try
        {
            
            this.name = din.readUTF();
            this.vorname = din.readUTF();
            this.age = din.readInt();
            
            din.close();
            bin.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        
    }
    
    /* ACCESSOR / MUTATOR methods */
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getVorname()
    {
        return vorname;
    }
    
    public void setVorname(String vorname)
    {
        this.vorname = vorname;
    }
    
    public int getAge()
    {
        return age;
    }
    
    public void setAge(int age)
    {
        this.age = age;
    }

}