/*
 * OOPFinder.java
 *
 * Created on 23. Februar 2006, 22:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.mobile.oop.util;

import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DataElement;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;
import org.coffeecrew.mobile.oop.Constants;

/**
 * This class is used to locate the remote Obex object passing service url.
 * The main purpose is that <a href="http://sourceforge.net/projects/bluecove/">BlueCove</a>
 * does not implement the <CODE>selectService()</CODE> method. This is a workaround, 
 * that should work on all implementations that support at least basic discovery 
 * mechanisms.
 * 
 * To transfer objects (you do not need this, but if you're interestet in the
 * connection url, this is the way to retrieve it)
 * 
 * Basic usage is:
 * 
 * <PRE>
 *    OOPFinder oopf = new OOPFinder();
 *    System.out.println("Connection: " + oopf.getConnectionURL());
 * </PRE>
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @since 0.1
 */
public class OOPFinder implements DiscoveryListener
{
    UUID[] uuidSet = {new UUID(Constants.SERVICE_UUID_STRING, true)};
    int[] attrSet = {0x0100, 0x0003, 0x0004, 0x0008};
    
    ServiceRecord serviceRecord;
    private String connectionURL;
    Vector deviceList;
    private Vector remoteDevices = new Vector();
    private boolean inquiryFinished = false;
    
    /**
     * Creates a new instance of OOPFinder, which is used to locate a remote Obex 
     * object passing service
     */
    public OOPFinder()
    {
    }
    
    /**
     * Executes the actual device inquiry.
     */
    public void inquire()
    {
        try
        {
            LocalDevice localDevice = LocalDevice.getLocalDevice();
            localDevice.setDiscoverable(DiscoveryAgent.NOT_DISCOVERABLE);
            
            DiscoveryAgent discoveryAgent = localDevice.getDiscoveryAgent();
        
            inquiryFinished = false;
            
            /* This seems to run of in a separate Thread, at least
             * on Nokia Phones
             * But not in the WTK emulator
             */
            discoveryAgent.startInquiry(DiscoveryAgent.GIAC, this);
            
            synchronized(this)
            {
                while (!inquiryFinished)
                {
                    try
                    {
                        this.wait();
                    }
                    catch (InterruptedException ex)
                    {
                        ex.printStackTrace();
                    }
                }    
            }
        }
        catch (BluetoothStateException ex)
        {
            ex.printStackTrace();
        }    
    }
    
    /**
     * Implementation as defined in the interface 
     * <CODE>javax.bluetooth.DiscoveryListener</CODE> this code is called from the 
     * implementation when an inquiry is completed.
     * @param discType How the inquiry completed; either INQUIRY_COMLETED, INQUIRY_ERROR or 
     * INQUIRY_TERMINATED
     */
    public void inquiryCompleted(int discType)
    {
        inquiryFinished = true;
        synchronized(this)
        { this.notify(); }
        /* Nothing special to do atm. */
//        String inqStatus = null;
        
//        if (discType == DiscoveryListener.INQUIRY_COMPLETED)
//        {
//            inqStatus = "[client:] Inquiry completed";
//        }
//        else if (discType == DiscoveryListener.INQUIRY_TERMINATED)
//        {
//            inqStatus = "[client:] Inquiry terminated";
//        }
//        else if (discType == DiscoveryListener.INQUIRY_ERROR)
//        {
//            inqStatus = "[client:] Inquiry error";
//        }
//        
//        //messages.append(inqStatus, null);
//        System.out.println(inqStatus);
    }
    
    /**
     * Implementation as defined in the interface 
     * <CODE>javax.bluetooth.DiscoveryListener</CODE> this code is called from the 
     * implementation when a service was discovered.
     * @param transID Transaction ID, that is posted back from the service search
     * @param servRecord The service record containing information from the remote device
     */
    public void servicesDiscovered(int transID, ServiceRecord[] servRecord)
    {
        
        for(int i = 0; i < servRecord.length; i++)
        {
            
            DataElement serviceNameElement = servRecord[i].getAttributeValue(0x0100);
            String serviceName = (String)serviceNameElement.getValue();
            
            /* Search for our service */
            if(serviceName.equals(Constants.SERVICE_NAME))
            {
                try
                {
                    connectionURL = servRecord[i].getConnectionURL(1,false);
                }
                catch (Exception e)
                {
                    /* Nothin useful here */
                }
            }
        }
    }
    
    
    
    /**
     * Implementation as defined in the interface 
     * <CODE>javax.bluetooth.DiscoveryListener</CODE> this code is called from the 
     * implementation when the service search finished.
     * @param transID The transaction ID that identifies the request that initiated the service search
     * @param respCode The status response code of the transaction
     */
    public void serviceSearchCompleted(int transID, int respCode)
    {
         /* We're not doing anything special atm. */
//        String searchStatus = null;
//        
//        if (respCode == DiscoveryListener.SERVICE_SEARCH_DEVICE_NOT_REACHABLE)
//        {
//            searchStatus = "Device not reachable";
//        }
//        else if (respCode == DiscoveryListener.SERVICE_SEARCH_NO_RECORDS)
//        {
//            searchStatus = "Service not available";
//        }
//        else if (respCode == DiscoveryListener.SERVICE_SEARCH_COMPLETED)
//        {
//            searchStatus = "Service search completed";
//        }
//        else if (respCode == DiscoveryListener.SERVICE_SEARCH_TERMINATED)
//        {
//            searchStatus = "Service search terminated";
//        }
//        else if (respCode == DiscoveryListener.SERVICE_SEARCH_ERROR)
//        {
//            searchStatus = "Service search error";
//        }
    }
    
    /**
     * Implementation as defined in the interface 
     * <CODE>javax.bluetooth.DiscoveryListener</CODE> this code is called from the 
     * implementation when a device was discovered.
     * @param remoteDevice The remote device found during the inquiry
     * @param cod The class of device, the remote device represents (e.g. mobile, laptop, ...)
     */
    public void deviceDiscovered(RemoteDevice remoteDevice, DeviceClass cod)
    {
        
        try
        {
            /* Add found device to the vector of remote devices */
            remoteDevices.addElement(remoteDevice);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
    
    /**
     * Fetches the connection URL which is needed to connect to the Obex object passing 
     * service.
     * @return The connection URL where the Obex object passing service was 
     * located or null if no service could be found
     */
    public String getConnectionURL()
    {
        /* provide automatic mechanism */
        inquire();
        findServices();
        
        if (connectionURL != null)
            return connectionURL;
        else
            throw new NullPointerException("ConnectionURL in OOPFinder null");
    }
    
    /**
     * This actually locates the Obex object passing service
     */
    public void findServices()
    {
        try {
			LocalDevice localDevice = LocalDevice.getLocalDevice();
			DiscoveryAgent discoveryAgent = localDevice.getDiscoveryAgent();
			RemoteDevice remoteDevice = null;

                            for(int i=0; i<remoteDevices.size(); i++){
				remoteDevice = (RemoteDevice)remoteDevices.elementAt(i);
				discoveryAgent.searchServices(attrSet, uuidSet, remoteDevice, this);
				try{
					Thread.sleep(2000);
				} catch (Exception e){
				}
			}

		}
		catch(Exception e) {
			e.printStackTrace();
		}
    }
    
}
