package org.coffeecrew.mobile.oop;

/**
 * This interface has to be implemented to
 * send objects over the provided ObexObjectPassing (OOP)
 * library. With this library you can send objects via bluetooth
 * connection with little effort. It maybe also useful for storing objects in RMS.
 * <br>
 * An example of a class implementing IObexObjectPassing looks like the following:
 * 
 * <PRE>
 * 
 * package org.coffeecrew.da.entity;
 * 
 * import java.io.ByteArrayInputStream;
 * import java.io.ByteArrayOutputStream;
 * import java.io.DataInputStream;
 * import java.io.DataOutputStream;
 * import java.io.IOException;
 * import org.coffeecrew.mobile.oop.IObexObjectPassing;
 * 
 * public class Person implements IObexObjectPassing
 * {
 *    // entity fields
 *    private String name = null;
 *    private String vorname = null;
 *    private int age = 0;
 *    
 *    // Globals
 *    private ByteArrayOutputStream bout = null;
 *    private DataOutputStream dout = null;
 *    
 *    private ByteArrayInputStream bin = null;
 *    private DataInputStream din = null;
 *    
 *    // Creates a new instance of Person
 *    public Person()
 *    {
 *    }
 *    
 *    public Person(String name, String vorname, int age)
 *    {
 *        this.name = name;
 *        this.vorname = vorname;
 *        this.age = age;
 *    }
 *    
 *    // Return the datastructure as byte[]
 *    public byte[] getAsByteArray()
 *    {
 *        bout = new ByteArrayOutputStream();
 *        dout = new DataOutputStream( bout );
 *        byte[] ret = null;
 *        
 *        try
 *        {
 *            
 *            // Write values
 *            dout.writeUTF(name);
 *            dout.writeUTF(vorname);
 *            dout.writeInt(age);
 *            dout.flush();
 *            
 *            //do temp copy so we can close the writers
 *             
 *            ret = bout.toByteArray();
 *            dout.close();
 *            bout.close();
 *        }
 *        catch (IOException ex)
 *        {
 *            ex.printStackTrace();
 *        }
 *        
 *        
 *        return ret;
 *    }
 *     
 *    public void setObjectData(byte[] ba)
 *    {
 *        bin = new ByteArrayInputStream(ba);
 *        din = new DataInputStream(bin);
 *        try
 *        {
 *            
 *            this.name = din.readUTF();
 *            this.vorname = din.readUTF();
 *            this.age = din.readInt();
 *            
 *            din.close();
 *            bin.close();
 *        }
 *        catch (IOException ex)
 *        {
 *            ex.printStackTrace();
 *        }
 *        
 *    }
 *    
 *    // ACCESSOR / MUTATOR methods
 *    public String getName()
 *    {
 *        return name;
 *    }
 *    
 *    public void setName(String name)
 *    {
 *        this.name = name;
 *    }
 *    
 *    public String getVorname()
 *    {
 *        return vorname;
 *    }
 *    
 *    public void setVorname(String vorname)
 *    {
 *        this.vorname = vorname;
 *    }
 *    
 *    public int getAge()
 *    {
 *        return age;
 *    }
 *    
 *    public void setAge(int age)
 *    {
 *        this.age = age;
 *    }
 * 
 * }
 * </PRE>
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @since 0.1
 */
public interface IObexObjectPassing
{
    /**
     * This makes the object aware of filling its contents once received the
     * data from a InputStream
     * @param objectData The byte array that comprises the objects data
     */
    public abstract void setObjectData(byte[] objectData);
    
    /** This returns the whole object data as byte[]
     *
     * @return The <b>data</b> of the object
     */
    public abstract byte[] getAsByteArray();
}
