/*
 * ObjectNotPassableException.java
 *
 * Created on 8. Januar 2006, 16:38
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.mobile.oop.exceptions;

/**
 * Defines a specific Exception to the Obex object passing library, which is thrown
 * if an object does not implement {@link org.coffeecrew.mobile.oop.IObexObjectPassing}
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @since 0.1
 */
public class ObjectNotPassableException extends java.lang.Exception
{
    
    /**
     * Creates a new instance of <code>ObjectNotPassableException</code> without detail message.
     */
    public ObjectNotPassableException()
    {
    }
    
    
    /**
     * Constructs an instance of <code>ObjectNotPassableException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public ObjectNotPassableException(String msg)
    {
        super(msg);
    }
}
