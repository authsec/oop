/*
 * Observable.java
 *
 * Created on 13. Februar 2006, 19:32
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.mobile.oop.util;

import java.util.Enumeration;
import java.util.Vector;

/**
 * This class is intended to be used if you want your object to be observable.
 * It reimplements <CODE>java.util.Observable</CODE> so you can also work with
 * the observer pattern using J2ME. This class also works in a J2SE environment
 * and can be used as a replacement for <CODE>java.util.Observable</CODE>
 *
 * @author Jens Frey <jens.frey@coffeecrew.org>
 * @version 0.1
 * @since 0.1
 */
public class Observable
{
    /* Holds information if object has changed or not
     */
    private boolean changed = false;
    
    /* The observers connected to this object */
    private Vector observers = null;
    
    /** Creates a new instance of Observable with zero observers attached
     */
    public Observable()
    {
        observers = new Vector();
    }
    
    /**
     * Adds an observer to this object which should be informed if the state of this
     * object changes. The observer added should not already be added.
     *
     * There is no need to <CODE>synchronize</CODE> this, because the
     * <CODE>java.util.Vector</CODE> already synchronizes adding of elements.
     *
     * @since 0.1
     * @param observer The observer which should be added.
     */
    public void addObserver(Observer observer)
    {
        if (observer == null)
            throw new NullPointerException("The observer added to " +
                    this.getClass().getName() + " was null!");
        
        observers.addElement(observer);
        
        /* to keep memory consumption small
         * trim the vector. This probably results in a performance loss regarding
         * speed
         */
        observers.trimToSize();
    }
    
    /**
     * Should be called if the state of the object is no longer changed or if all
     * attached observer have been notified about the state change.
     */
    protected synchronized void clearChanged()
    {
        this.changed = false;
    }
    
    /**
     * Returns the number of observers that are attached to this object
     * @return The number of observers currently attached to this object
     */
    public int countObservers()
    {
        return observers.size();
    }
    
    /**
     * Deletes the specified observer from the list of observers so no more updates
     * will be delivered to the observer
     * @param observer The observer to be deleted
     */
    public void deleteObserver(Observer observer)
    {
        observers.removeElement(observer);
    }
    
    /**
     * Removes all currently attached observers from this object
     */
    public void deleteObservers()
    {
        observers.removeAllElements();
    }
    
    /**
     * If any attribute within the object changed this method returns true
     *
     * @return true if the state of the object has changed otherwise false
     *
     * @see #setChanged()
     * @see #clearChanged()
     */
    public boolean hasChanged()
    {
        return changed;
    }
    
    /**
     * Notifies attached observers that the state of this objet has changed
     * @see #notifyObservers(Object)
     */
    public void notifyObservers()
    {
        notifyObservers(null);
    }
    
    /**
     * Notifies attached observers that the state of this objet has changed
     * @param arg Argument to the observers update method
     */
    public void notifyObservers(Object arg)
    {
        if (!hasChanged())
            return;

        /* To bybass concurrent modifications which
         * could eventually be handled incorrectly
         * copy all elements into a separate
         * array (this should be relatively fast, as 
         * copyInto() should use System.arraycopy
         */
        Observer[] observersCopy = new Observer[observers.size()];
        observers.copyInto(observersCopy);
       
        for (int i=0; i < observersCopy.length; i++)
        {
            (observersCopy[i]).update(this, arg);
        }
        
        clearChanged();
    }
    
    /** Mark the object as having changed
     * it's state. <code>hasChanged()</code> returns <code>true</code>
     * after execution
     *
     * @see #hasChanged()
     */
    protected synchronized void setChanged()
    {
        this.changed = true;
    }
    
}
