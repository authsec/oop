package org.coffeecrew.mobile.oop.impl;

import de.avetana.javax.obex.ClientSession;
import de.avetana.javax.obex.HeaderSet;
import de.avetana.javax.obex.Operation;
import de.avetana.javax.obex.ResponseCodes;
import de.avetana.obexsolo.OBEXConnector;
import java.io.IOException;
import javax.microedition.io.Connection;
import org.coffeecrew.mobile.oop.*;
import org.coffeecrew.mobile.oop.exceptions.ObjectNotPassableException;
import org.coffeecrew.mobile.oop.util.OOPFinder;
import org.coffeecrew.mobile.oop.util.Observable;

/**
 * This class is intended to be used to transfer a <I>single</I> object which
 * implements {@link IObexObjectPassing} to a remote device which has an instance
 * of {@link ObjectReceiver} running
 * 
 * The transfer runns of in a separate thread. The calling object can be notified
 * if the transfer finished, if it implements the {@link org.coffeecrew.mobile.oop.util.Observer} interface.
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @see IObexObjectPassing
 * @see ObjectReceiver
 * @since 0.1
 * @see BulkObjectPusher
 */
public class ObjectPusher extends Observable implements Runnable
{
    
    private String connectionURL  = null;
    private IObexObjectPassing ioop;
    
    private ClientSession session = null;
    private Operation op = null;
    
    /**
     * Creates a new instance of <CODE>ObjectPusher</CODE>
     *
     * This class pushes the given Object to the given device address
     * once it is createt it will run as a seperate thread.
     *
     * @param transferObject Object to push to receiving client (needs to implement {@link IObexObjectPassing}
     * 
     * @throws ObjectNotPassableException if the object to transfer does
     * not implement IObexObjectPassing
     */
    //public ObjectPusher(Object transferObject, String connectionURL) throws ObjectNotPassableException //, BluetoothStateException
    public ObjectPusher(Object transferObject) throws ObjectNotPassableException //, BluetoothStateException
    {
        /* The object is not transferable because we need that interface to
         * be implemented
         */
        if ( !(transferObject instanceof IObexObjectPassing) )
            throw new ObjectNotPassableException("The Object to be transferred has to " +
                    "implement the IObexObjectPassing interface");
      
        /* We do automagically find the peer now */
        this.ioop = (IObexObjectPassing)transferObject;

        /* Start the Thread here, so the exception can be thrown if necessary
         * do not change this order
         */
        Thread detach = new Thread(this);
        detach.start();
        
    }
    
    /**
     * The actual execution method which transfers the object to the remote device.
     */
    public void run()
    {
        HeaderSet hs = null;
        
        try
        {
            //LocalDevice ld = LocalDevice.getLocalDevice();
            //DiscoveryAgent agent = ld.getDiscoveryAgent();
            String tmpURL = null;
            
            OOPFinder oopf = new OOPFinder();

            /* We cannot use DiscoveryAgent selectService method, because
             * bluecove does not support it
             * tmpURL = agent.selectService(new UUID(Constants.SERVICE_UUID_STRING, true), ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false);
             */
            try
            {
                tmpURL = oopf.getConnectionURL();
            connectionURL = "btgoep" + tmpURL.substring(5);
            }
            catch (NullPointerException ex)
            {
                /* Nothing we can do */
            }
            
            
            Connection con = null;
            try
            {
                con = (Connection) OBEXConnector.open(connectionURL);
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }
            session = (ClientSession) con;
            hs = session.createHeaderSet();
            
            /* Make sure you do send the class name as Header Name
             * field. so we can use this for pure object transactions
             * Maybe add extra Field Sequence
             */
            hs.setHeader(hs.NAME, ioop.getClass().getName());
            HeaderSet response = session.connect(hs);
            
            if (response.getResponseCode() != ResponseCodes.OBEX_HTTP_OK)
            {
                throw new IOException("Response Code from Push not ok");
            }
            
            op = session.put(hs);
            op.openOutputStream().write(ioop.getAsByteArray());
            op.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        /* mark this observable as changed */
        setChanged();
        /* When thread finished then fire obeserver updates */
        notifyObservers();
    }
}
