/*
 * InspectBT.java
 *
 * Created on 24. Februar 2006, 15:19
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.mobile.oop.util;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.LocalDevice;

/**
 * Supplies a convienient way to achieve system information from the underlying
 * bluetooth implementation
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @since 0.1
 */
public class InspectBT
{
    LocalDevice local = null;
    StringBuffer sb = null;
    
    /** Creates a new instance of InspectBT */
    public InspectBT()
    {
        this.sb = new StringBuffer();
    }
    
    /**
     * Gets all found system properties.
     * @return All system information or error message
     */
    public String getAllProperties()
    {
        try
        {
            local = LocalDevice.getLocalDevice();
        }
        catch (BluetoothStateException ex)
        {
            sb.append("Unable to get LocalDevice\n" + ex.getMessage());
            return sb.toString();
        }
        
        /* Get device parameters */
        sb.append("Local device address: " + local.getBluetoothAddress() + "\n");
        String friendlyName = local.getFriendlyName();
        if (friendlyName != null)
        {
            sb.append("Friendly name: " + friendlyName + "\n");
        }
        else
        {
            sb.append("Friendly name: [unable to retrieve]\n");
        }
        /* Ask for current discoverable mode */
        int discoverableMode = local.getDiscoverable();
        sb.append("Discoverable mode: ");
        
        switch(discoverableMode)
        {
            case DiscoveryAgent.GIAC:
                sb.append("General [GIAC]\n");
                break;
            case DiscoveryAgent.LIAC:
                sb.append("Limited [LIAC]\n");
                break;    
            case DiscoveryAgent.NOT_DISCOVERABLE:
                sb.append("Not discoverable\n");
                break;
            default: 
                sb.append("Mode unknown [" + Integer.toString(discoverableMode, 16) + "]\n");
                break;
        }
        
        /* default properties (need not to be checked for null,
         * because they have to be implemented
         */
        sb.append("API Version [" + local.getProperty("bluetooth.api.version") + "]\n");
        sb.append("Master switch [" + local.getProperty("bluetooth.master.switch") + "]\n");
        sb.append("Max service attributes in record [" + local.getProperty("bluetooth.sd.attr.retrievable.max") + "]\n");
        sb.append("Max. Number of connected Devices [" + local.getProperty("bluetooth.connected.devices.max") + "]\n");
        sb.append("L2CAP receive MTU [" + local.getProperty("bluetooth.l2cap.receiveMTU.max") + "]\n");
        sb.append("Max. number of concurrent service discoveries [" + local.getProperty("bluetooth.sd.trans.max") + "]\n");
        sb.append("Device able to respond to inquiry while connected to other device? [" + local.getProperty("bluetooth.connected.inquiry.scan") + "]\n");
        sb.append("Device able to accept a new remote connection while connected to other device? [" + local.getProperty("bluetooth.connected.page.scan") + "]\n");
        sb.append("Device able to start an inquiry while connected to other device? [" + local.getProperty("bluetooth.connected.inquiry") + "]\n");
        sb.append("Device able to establish a connection if currently connected to other device? [" + local.getProperty("bluetooth.") + "]\n");
        
        return sb.toString();
    }
}
