package org.coffeecrew.mobile.oop;

/**
 * All used constants, regarding to the OBEX Object Passing library, are defined
 * in this class.
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @since 0.1
 */
public class Constants
{
    /**
     * Specifies the string for the UUID the ObexObjectPassing Mechanism should be
     * using. This could be any 4-Digit number as string (at the moment there is no long UUID
     * field in use for this service).
     */
   public static final String SERVICE_UUID_STRING = "1234";   
    /**
     * Specifies the name of the service which will be started.
     */
   public static final String SERVICE_NAME = "OBEXObjectPassing";
}
