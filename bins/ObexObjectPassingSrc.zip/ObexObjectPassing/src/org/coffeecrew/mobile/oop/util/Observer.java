/*
 * Observer.java
 *
 * Created on 13. Februar 2006, 19:29
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.mobile.oop.util;

/**
 * Interface that is implemented when a class wants to be informed of changes
 * in Observable objects.
 *
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @since 0.1
 * @see Observable
 */
public interface Observer
{
    /**
   * This method is called whenever the observable object changes, and has
   * called <code>notifyObservers</code>. The Observable object can pass
   * arbitrary information in the second parameter.
   *
   * @param observable the Observable object that changed
   * @param arg arbitrary information, usually relating to the change
   */
  void update(Observable observable, Object arg);
}
