/*
 * ObjectReceiver.java
 *
 * Created on 8. Januar 2006, 02:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.mobile.oop.impl;

import de.avetana.javax.obex.SessionNotifier;
import de.avetana.obexsolo.OBEXConnector;
import java.io.IOException;
import java.util.Vector;
import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.UUID;
import javax.microedition.io.Connection;
import org.coffeecrew.mobile.oop.*;
import org.coffeecrew.mobile.oop.util.Observable;

/**
 * This class should be used on the receiving side of the transfer. This class is
 * observable, so you can attach an <CODE>Observer</CODE> object to it, to be
 * notified if an object was received.
 * <br>
 * <CODE>ObjectReceiver</CODE> usage is pretty simple, you just have to instance
 * it like:
 * <PRE>new ObjectReceiver(receivedObjects);</PRE>
 * or if you want an {@link org.coffeecrew.mobile.oop.util.Observer} to be 
 * attached, simply do:
 * <PRE>new ObjectReceiver(receivedObjects).addObserver(observer);</PRE>
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @since 0.1
 */
public class ObjectReceiver extends Observable implements Runnable
{
    
    /* The received object will be stored to this vector */
    private Vector receivedObjectStore = null;
    
    SessionNotifier sn = null;
    
    /** Creates a new instance of ObjectReceiver.
     *
     * This class is responsible for receiving the object
     * that is send to the remote device with the ObjectPusher class
     * <br>
     * Remember to enable discovery mode, this MAY not be required on a real
     * phone but if using in WTK this is needed.
     * 
     * @param receivedObjects The received object will be added to this vector
     * which can hold lots of objects you receive.
     *
     */
    public ObjectReceiver(Vector receivedObjects)
    {
        this.receivedObjectStore = receivedObjects;
        // we have to initialize a system in different thread...
        Thread accepterThread = new Thread(this);
        accepterThread.start();
    }
    
    /**
     * Starts the receiving thread. 
     * Sets the device discoverable.
     */
    public void run()
    {
        try
        {
            /* Set LocalDevice discoverable */
            LocalDevice ld = null;
            try
            {
                ld = LocalDevice.getLocalDevice();
            }
            catch (BluetoothStateException ex)
            {
                ex.printStackTrace();
            }
            if (!ld.setDiscoverable(DiscoveryAgent.GIAC))
            {
                throw new IOException("Can't set discoverable mode...");
            }
            
            UUID uuid = new UUID(Constants.SERVICE_UUID_STRING, true);
            //String url = "btgoep://localhost:" + uuid.toString() + ";name="+ Constants.SERVICE_NAME +";authenticate=false;master=true;encrypt=false";
            /* Removed Master=true switch, so you can run both client and server on a single device */
            String url = "btgoep://localhost:" + uuid.toString() + ";name="+ Constants.SERVICE_NAME +";authenticate=true;encrypt=true";
           
            SessionNotifier sn = null;
            Connection con = null;
            while(true)
            {
                sn = (SessionNotifier) OBEXConnector.open(url);
                con = ((SessionNotifier) sn).acceptAndOpen(new ReceiverRequestHandler(receivedObjectStore, sn));
                
                /* Synchronize threads so we can close the connection
                 * after the transfer finished.
                 */
                synchronized (sn)
                {
                    try
                    {
                        sn.wait();
                    }
                    catch (InterruptedException ex)
                    {
                        ex.printStackTrace();
                    }
                }
                
                /* Close connection to sending device */
                con.close();
                
                setChanged();
                notifyObservers();
            }
        }
        catch (SecurityException ex)
        {
            ex.printStackTrace();
        }
        catch (ClassCastException ex)
        {
            ex.printStackTrace();
        }
        catch (BluetoothStateException ex)
        {
            ex.printStackTrace();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }   
    }
}
