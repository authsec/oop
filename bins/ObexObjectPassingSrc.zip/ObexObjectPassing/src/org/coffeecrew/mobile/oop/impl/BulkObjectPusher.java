package org.coffeecrew.mobile.oop.impl;

import java.util.Enumeration;
import java.util.Vector;
import org.coffeecrew.mobile.oop.exceptions.ObjectNotPassableException;
import org.coffeecrew.mobile.oop.util.Observable;
import org.coffeecrew.mobile.oop.util.Observer;

/**
 * This class implements a mechanism to send multiple objects
 * that are stored in a <CODE>java.util.Vector</CODE> to safely
 * transfer them to a remote device. All the threading issues are
 * covert within this class. You can also use {@link ObjectPusher} to transfer
 * multiple objects to a remote device but then you have to synchronize the threads 
 * on your own.
 * <br>
 * <CODE>BulkObjectPusher</CODE> usage is like follows:
 * <PRE>
 *                // create your objects
 *                Person p = new Person();
 *                p.setName("Schneider");
 *                p.setVorname("Rosemarie");
 *                p.setAge(37);
 *                              
 *                Person hans = new Person();
 *                hans.setName("Peter");
 *                hans.setVorname("Hans");
 *                hans.setAge(37);
 *                
 *                //staff them into a vector
 *                Vector transferringObjects = new Vector();
 *                transferringObjects.addElement(p);
 *                transferringObjects.addElement(hans);
 *                
 *                //happy pushing
 *                new BulkObjectPusher(transferringObjects).addObserver(this);
 * </PRE>
 * @author Jens Frey &lt;jens.frey@coffeecrew.org&gt;
 * @see ObjectPusher
 * @see ObjectReceiver
 * @since 0.1
 */
public class BulkObjectPusher extends Observable implements Observer, Runnable
{
    private Vector objectsToTransfer = null;
    
    private Object objectInTransfer = null;
    
    /**
     * Creates a new instance of BulkObjectPusher which then sends the given 
     * <CODE>java.util.Vector</CODE> of objects to the remote device where an
     * instance of {@link ObjectReceiver} is running.
     * @param objectsToTransfer The objects encapsulated in a <CODE>java.util.Vector</CODE> that should be
     * transferred to the remote device.
     */
    public BulkObjectPusher(Vector objectsToTransfer)
    {
        this.objectsToTransfer = objectsToTransfer;
        
        Thread detach = new Thread(this);
        detach.start();
    }

    /**
     * The actual working method
     */
    public void run()
    {
        Enumeration objects = objectsToTransfer.elements();
    
        while (objects.hasMoreElements())
        {
            try
            {
                objectInTransfer = objects.nextElement();
                new ObjectPusher(objectInTransfer).addObserver(this);
            } catch (ObjectNotPassableException ex)
            {
                ex.printStackTrace();
            }
            
            /* Wait until we receive an update, that the current object 
             * was sent.
             */
            synchronized(this)
            {
                try
                {
                    this.wait();
                } catch (InterruptedException ex)
                {
                    ex.printStackTrace();
                }
            }
        }
        
        setChanged();
        notifyObservers();
    }
    
    /**
     * This method causes this thread to send the next object by notifying
     * the run method that the object in transfer has been sent.
     * @param observable The observable which notified the change
     * @param arg Argument to transfer additional information from the observable to the 
     * {@link Observer}
     */
    public void update(Observable observable, Object arg)
    {
        /* The object finished the transfer */
        synchronized (this)
        {
            this.notify();
        }
    }
    

}
