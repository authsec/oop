/*
 * ReceiverRequestHandler.java
 *
 * Created on 16. Februar 2006, 15:42
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.coffeecrew.mobile.oop.impl;

import de.avetana.javax.obex.HeaderSet;
import de.avetana.javax.obex.Operation;
import de.avetana.javax.obex.ResponseCodes;
import de.avetana.javax.obex.ServerRequestHandler;
import de.avetana.javax.obex.SessionNotifier;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import org.coffeecrew.mobile.oop.IObexObjectPassing;

/**
 * This class is use internally by ObjectReceiver. But can be use as a request 
 * handler for put operations
 * @author Jens Frey <jens.frey@coffeecrew.org>
 * @since 0.1
 */
public class ReceiverRequestHandler extends ServerRequestHandler
{
    /* The received object will be stored to this vector */
    private Vector receivedObjectStore = null;
    
    private Object receivedObject = null;
    
    private SessionNotifier sn = null;
    
    /**
     * Creates a new instance of ReceiverRequestHandler
     * @param receivedObjectsStore The <CODE>java.util.Vector</CODE> to which the received objects are stored.
     * @param sn The session notifier to synchronize the threads
     */
    public ReceiverRequestHandler(Vector receivedObjectsStore, SessionNotifier sn)
    {
        this.receivedObjectStore = receivedObjectsStore;
        this.sn = sn;
    }
    
    /* Someone is putting sth. onto my device
     * This method is called by the JSR-82 implementation
     */
    /**
     * This request handler should only be ware of handling put operations. This method
     * implements the put operationa an all necessary steps to reconstruct the object 
     * received from a {@link org.coffeecrew.mobile.oop.impl.ObjectPusher}
     * @param operation The headers sent by the client
     * @return Response code as defined in ResponseCodes. In this case only OBEX_HTTP_OK 
     */
    public int onPut(Operation operation)
    {
        try
        {
            HeaderSet hs = operation.getReceivedHeaders();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            InputStream is = operation.openInputStream();
            
            /* Read every single byte from the input stream
             * and write it to an ByteArrayOutputStream so we do
             * not have to matter about the size of the input
             */
            
            while (is.available() > 0)
                baos.write(is.read());
            
            /* close immediately after read */
            is.close();
            
            /* We now do have all data received, and have
             * to construct a object which actually holds
             * the data. The class description is taken from
             * the name field in the header. The other way we
             * would have to extract the data carefully from the
             * byte array
             */
            Class clazz = Class.forName((String)hs.getHeader(HeaderSet.NAME));
            
            /* Create object of given type and set data read
             * so the object is reconstructed correctly
             */
            receivedObject = clazz.newInstance();
            ((IObexObjectPassing)receivedObject).setObjectData(baos.toByteArray());
            
            /* Add object to objectStore so you can later use it.
             * http://www.javaworld.com/javaworld/javaqa/2001-06/03-qa-0622-vector.html
             */
            receivedObjectStore.addElement(receivedObject);
            
            /* Clean shutdown of connections */
            baos.close();
            
        }
        catch (ClassNotFoundException ex)
        {
            ex.printStackTrace();
        }
        catch (IllegalAccessException ex)
        {
            ex.printStackTrace();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        catch (InstantiationException ex)
        {
            ex.printStackTrace();
        }

        /* Notify the calling thread that we are finished now */
        synchronized (sn)
        {
            try
            {
                sn.notify();
            } finally
            {
            }
        }
        return ResponseCodes.OBEX_HTTP_OK;
    }
}
